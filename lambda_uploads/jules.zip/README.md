# Jules the Life Story Chatbot (Project Name Durga)

Jules is a chatbot that talks to older people and asks them questions about their life, to record their stories, wisdom, and thoughts for younger generations

Durga.py is the main file to run in Python.
Knowledge.py has her brain and database.
